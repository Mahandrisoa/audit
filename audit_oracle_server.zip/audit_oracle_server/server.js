/******************************************************************************
 * NAME
 *   server.js
 *
 * DESCRIPTION
 *   The main entry point for the Node.js application. This sets up end points
 *   for static files, the application api, as well as the database for query
 *   result change notifications.
 *
 *****************************************************************************/

var domain = require('domain');
var express = require('express');
var bodyParser = require('body-parser');
var http = require('http');
var morgan = require('morgan');
var serveStatic = require('serve-static');
var dbconfig = require('./server/dbconfig.js');
var database = require('./server/database.js');
var api = require('./server/api.js');
var socketio = require('./server/socketio.js');
var app;
var httpServer;
var serverDomain = domain.create();
var openConnections = {};
var timers = require('timers');

serverDomain.on('error', function (err) {
    console.error('Domain error caught', err);
    shutdown();
});

serverDomain.run(initApp);

function initApp() {
    app = express();
    httpServer = http.Server(app);
    socketio.listen(httpServer);

    // app.use(morgan('combined'));
    app.use(bodyParser.urlencoded({ extended: false }));
    app.use(bodyParser.json());

    app.use('/', serveStatic(__dirname + '/public'));

    app.use('/vendor', serveStatic(__dirname + '/bower_components'));

    app.use(function (req, res, next) {
        res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
        next();
    });

    app.use('/api', api.getRouter());    

    app.get('/db', socketio.handleDatabaseCallback);

    httpServer.on('connection', function (conn) {
        var key = conn.remoteAddress + ':' + conn.reportPort;

        openConnections[key] = conn;

        conn.on('close', function () {
            delete openConnections[key];
        });
    });    

    database.connect(dbconfig, function () {
        httpServer.listen(3000, function () {
            console.log('Webserver listening on localhost:3000');
            console.log('you can send socket!');
        });
    });    
}

function shutdown() {
    console.log('Shutting down');

    httpServer.close(function () {
        console.log('Web server closed');

        database.disconnect(function () {
            console.log('DB disconnected, exiting process');
            process.exit(0);
        });
    });

    for (key in openConnections) {
        openConnections[key].destroy();
    }
}

