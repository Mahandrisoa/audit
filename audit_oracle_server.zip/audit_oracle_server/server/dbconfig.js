module.exports = {
    user: 'finance',
    password: 'Fin371vORT95N0mE19cP1r1N3',
    connectString: '192.168.10.109:1521/si00',
    // poolMax: 44,
    // poolMin: 2,
    // poolIncrement: 5,
    //poolTimeout: 4
};