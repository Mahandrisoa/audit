module.exports = {
    user: 'starfrx',
    password: 'Frx1720',
    connectString: '192.168.10.109:1521/si00',
    poolMax: 1000,
    poolMin: 100,
    poolIncrement: 5,
    poolTimeout: 2
};