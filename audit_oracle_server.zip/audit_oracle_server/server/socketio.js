/******************************************************************************
 * NAME
 *   socketio.js
 *
 * DESCRIPTION
 *   Contains the logic related to Socket.IO.
 *
 *****************************************************************************/

var http = require('http');
var socketio = require('socket.io');
var io;

function listen(httpServer) {
    io = socketio(httpServer);
    io.on('connection', function(socket){        
        handleStartListening(socket);
        handleStopListening(socket);
    });    
}

module.exports.listen = listen;

function handleStartListening(socket) {
    socket.emit('startListening', {data : "server starts"});        
    // socket.on('startListening', function(room) {
    //     socket.join(room.name);
    // });
}

function handleStopListening(socket) {
    socket.on('stopListening', function(room) {
        socket.leave(room.name);
    });
}

function handleDatabaseCallback(req, res) {
    var options = {
        host: 'localhost',
        port: 3000,
        path: '/api/employees'
    };

    http.get(options, function(resp){
        var body = '';

        resp.on('data', function(chunk){
            body += chunk.toString();
        });

        resp.on('end', function(chunk){
            var parsed = JSON.parse(body);

            console.log(parsed);

            io.to('employees').emit('change', parsed.rows);

            res.send();
        });
    }).on('error', function(e){
        console.log("Got error: " + e.message);
    });
}

module.exports.handleDatabaseCallback = handleDatabaseCallback;