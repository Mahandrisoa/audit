module.exports = {
    user: 'starfrx',
    password: 'Frx1720',
    connectString: '192.168.11.143:1521/us50',
    poolMax: 44,
    poolMin: 2,
    poolIncrement: 5,
    poolTimeout: 4
};