function tablespaceCtrl($scope, $element, $attrs, tablespaceService) {
    var ctrl = this;
    this.$onInit = function () {
        tablespaceService.getTablespaces(ctrl.audit.DIVISION, 'tablespace')
            .then(function (response) {
                ctrl.tablespaces = response.data;
                ctrl.tablespaces.forEach(tbl => {
                    var r3 = parseFloat((tbl.TAILLE_UTILISE * 100) / tbl.TAILLE_OBJET).toFixed(3);
                    tbl['percentUsed'] = r3;                    
                });
            });
    }
}

angular.module('app')
    .component('tablespace', {
        templateUrl: '/components/tablespace/tablespace.html',
        controller: tablespaceCtrl,
        bindings: {
            audit: '<'
        }
    }).service('tablespaceService', function ($http) {
        this.getTablespaces = function (division, objType) {
            return $http.get('/api/objet_details?division=' + division + '&date=05/01/2018&objet=' + objType + '');
        }
    });