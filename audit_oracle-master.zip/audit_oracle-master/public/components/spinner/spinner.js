function spinnerCtrl() {
    this.$onActivate = function () {
        alert("activated");
    }
}
angular.module('app')
    .component('spinner', {
        templateUrl : '/components/spinner/spinner.html',
        controller  : spinnerCtrl,
    })