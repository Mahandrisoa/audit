var express = require('express');
var oracledb = require('oracledb');
var database = require('./database.js');

function getRouter() {
    var router = express.Router();

    router.route('/audits')
        .get(getAudits);

    router.route('/objet_details')
        .get(getObjetDetails);

    router.route('/disque_details')
        .get(getDisqueDetails);
    return router;
}

var odStrategy = require('./shared/objet_detail_strategy');

function getObjetDetails(req, res, next) {
    database.getPool().getConnection(function (err, connection) {
        if (err) return next(err);
        var statement = odStrategy.operation(req);
        console.log(statement);
        connection.execute(
            statement,
            {}, //no binds
            {
                outFormat: oracledb.OBJECT
            },
            function (err, results) {
                if (err) {
                    return connection.release(function () {
                        next(err);
                    });
                }

                connection.release(function (err) {
                    if (err) return next(err);
                    res.send(results['rows']);
                });
            }
        );
    });
}

var strategy = require('./shared/strategy.js');

function getDisqueDetails(req, res, next) {
    database.getPool().getConnection(function (err, connection) {
        if (err) return next(err);
        var statement = strategy.operation(req);
        connection.execute(
            statement,
            {}, //no binds
            {
                outFormat: oracledb.OBJECT
            },
            function (err, results) {
                if (err) {
                    return connection.release(function () {
                        next(err);
                    });
                }

                connection.release(function (err) {
                    if (err) return next(err);
                    res.send(results['rows']);
                });
            }
        );
    });
}

function getAudits(req, res, next) {
    database.getPool().getConnection(function (err, connection) {
        if (err) return next(err);
        var statement = 'SELECT * FROM AUDIT_JOURNALIER';
        if (req.query.division === undefined && req.query.date !== undefined) {
            /**
             * this section will be used by the client rich application 
             * statement += ' WHERE DATE_AUDIT_JOURNALIER= TO_DATE(\'' + req.query.date + '\',\'dd-mm-yyyy\')';
             */
            statement = 'select DIVISION_NAME ,DIVISION,DIVISION_TYPE, CACHE_HIT_RATIO, TO_CHAR(DATE_AUDIT_JOURNALIER,\'DD/MM/YYYY hh24:mi:ss\') DATE_AUDIT_JOURNALIER ' +
                'from ( select * from AUDIT_JOURNALIER where TO_CHAR( DATE_AUDIT_JOURNALIER ,\'dd/mm/yyyy\')=\'' + req.query.date + '\') ' +
                'where date_audit_journalier = (select max(DATE_AUDIT_JOURNALIER) from (select * from AUDIT_JOURNALIER where TO_CHAR( DATE_AUDIT_JOURNALIER ,\'dd/mm/yyyy\')=\'' + req.query.date + '\'))';


        } else if (req.query.date === undefined && req.query.division !== undefined) {
            statement += ' WHERE DIVISION=\'' + req.query.division + '\'';
        } else if (req.query.date !== undefined && req.query.division !== undefined) {
            statement +=
                ' WHERE DIVISION=\'' + req.query.division + '\' ' +
                'AND DATE_AUDIT_JOURNALIER= TO_DATE(\'' + req.query.date + '\',\'dd-mm-yyyy\')';
        }
        console.log(statement);
        connection.execute(
            statement,
            {}, //no binds
            {
                outFormat: oracledb.OBJECT
            },
            function (err, results) {
                if (err) {
                    return connection.release(function () {
                        next(err);
                    });
                }

                connection.release(function (err) {
                    if (err) return next(err);
                    res.send(results['rows']);
                });
            }
        );
    });
}

module.exports.getRouter = getRouter;