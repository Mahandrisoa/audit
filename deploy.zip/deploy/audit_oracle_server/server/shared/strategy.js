/**
 * Only case date_division is needed for the Angularjs client application 
 * The others are needed for testing the API on http://host:port/api/
 */
var util = require('./util.js');

function operation(req) {
    var statement = 'SELECT * FROM AUDIT_JOURNALIER_DISQUE_DETAIL ';
    var owners = util.hasQueries(req,["date", "division", "serveur"]);    
    switch (owners.predicates) {
        case 'date':
            statement +=
                'WHERE DATE_AUDIT_JOURNALIER= TO_DATE(\'' + req.query.date + '\',\'dd-mm-yyyy\')';
            break;
        case 'division':
            statement +=
                'WHERE DIVISION= \'' + req.query.division + '\'';
            break;
        case 'serveur':
            statement +=
                'WHERE SERVEUR= \'' + req.query.serveur + '\'';
            break;
        case 'date_division': // take the most recent detail_disk on the db
        var date = req.query.date;
            
            statement = 
                'SELECT NOM_DISQUE, ESPACE_TOTAL, ESPACE_LIBRE,serveur,TO_char( DATE_AUDIT_JOURNALIER,\'DD/MM/YYYY HH24:MI:SS\'),DIVISION ' +
                'FROM audit_journalier_disque_detail ' + 
                'WHERE DATE_AUDIT_JOURNALIER = ' +
                '(   SELECT MAX(DATE_AUDIT_JOURNALIER) FROM ' + 
                '    (' + 
                '        SELECT * FROM audit_journalier_disque_detail WHERE DIVISION=\''+ req.query.division + '\' ' +
                '        AND TO_CHAR(DATE_AUDIT_JOURNALIER,\'DD/MM/YYYY\') = \''+ req.query.date + '\'' +
                '    )' + 
                ')';
            break;
        case 'date_serveur':
            statement +=
                'WHERE DATE_AUDIT_JOURNALIER= TO_DATE(\'' + req.query.date + '\',\'dd-mm-yyyy\') ' +
                'AND SERVEUR= \'' + req.query.serveur + '\'';
            break;
        case 'division_serveur':
            statement +=
                'WHERE DIVISION= \'' + req.query.division + '\'' +
                'AND SERVEUR= \'' + req.query.serveur + '\'';
            break;
        case 'date_division_serveur':
            statement +=
                'WHERE DATE_AUDIT_JOURNALIER= TO_DATE(\'' + req.query.date + '\',\'dd-mm-yyyy\') ' +
                'AND DIVISION= \'' + req.query.division + '\' ' +
                'AND SERVEUR= \'' + req.query.serveur + '\'';
            break;
    }
    return statement
}

module.exports.operation = operation